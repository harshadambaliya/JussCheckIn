<?php
    include('include/header.php');
?>
<!-- Landing Section Start -->
<section class="jci-error-landing-section">
    <div class="container">
        <h1 class="jci-section-title">404</h1>
        <p class="jci-section-description">oops! page not found.</p>
        <a href="index.php" class="btn btn-light">Go to Home</a>
    </div>
</section>
<!-- Landing Section End -->
<?php
    include('include/footer.php');
?>